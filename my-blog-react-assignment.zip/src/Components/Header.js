import React from 'react'

function Header() {
    return (
        <header>
            <h1>
                Blogs By Akshay Sen
            </h1>
        </header>
    )
}

export default Header
